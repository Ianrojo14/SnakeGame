package mx.edu.utch.serpientejuego


import android.content.Context
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import java.util.Random
import kotlin.math.pow
import kotlin.math.sqrt

class GameLogic(private val context: Context) {
    private val random = Random()
    val snakeSegments = mutableListOf<ImageView>()
    var delayMillis = 30L
    var score = 0

    fun initializeSnake(board: ViewGroup) {
        val snake = ImageView(context).apply {
            setImageResource(R.drawable.snake)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        board.addView(snake)
        snakeSegments.add(snake)
    }

    fun initializeFood(board: ViewGroup): ImageView {
        val meat = ImageView(context).apply {
            setImageResource(R.drawable.meat)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        board.addView(meat)
        positionFoodRandomly(meat)
        return meat
    }

    fun positionFoodRandomly(meat: ImageView) {
        meat.x = (random.nextInt(801) - 400).toFloat()
        meat.y = (random.nextInt(801) - 400).toFloat()
    }

    fun checkFoodCollision(snake: ImageView, meat: ImageView, scoreView: TextView): Boolean {
        val distanceThreshold = 50
        val distance = sqrt((snake.x - meat.x).pow(2) + (snake.y - meat.y).pow(2))
        if (distance < distanceThreshold) {
            score++
            scoreView.text = "puntuación: $score"
            delayMillis--
            positionFoodRandomly(meat)
            return true
        }
        return false
    }

}
