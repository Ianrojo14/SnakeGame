import android.app.Activity
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import mx.edu.utch.serpientejuego.GameLogic
import mx.edu.utch.serpientejuego.R

class MainActivity : Activity() {
    private lateinit var gameLogic: GameLogic
    private lateinit var meat: ImageView
    private lateinit var board: ViewGroup
    private lateinit var score2: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        gameLogic = GameLogic(this)
        board = findViewById<RelativeLayout>(R.id.board)
        score2 = findViewById<Button>(R.id.score2)

        gameLogic.initializeSnake(board)
        meat = gameLogic.initializeFood(board)


    }
}
